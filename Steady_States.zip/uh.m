function [z] = uh(X,Y)
%This is just the function uh where X represents uoi and Y respresents uob.
%The conditions required on uh are uh(uoi,uoi)=1 and uh(uoi,uob) < uob.

%Variable to set which case one is in

ca = 4;

%Variable to control the mollifier (integration region)

delta = 0.1;

%Variable to control the number of wax layer regions in cases 2 and 4.

N = 2;

% Case 0 (corresponding to case (A) in the paper).

if (ca==0)
    
    z   = 1 + ((Y - X)/3);

end

% Case 1 (corresponding to unmollified (B) in the paper). Mollified version
% of this case is below.

if (ca==1)

    if Y < 1
   
        z = 1 + (Y - 1) + ((1-X)/4);
    
    else
    
        z = 1 + ((Y-X)/4);
  
    end

end

% Case 2
% In this case we would get N wax bumps in the wax layer (for certain k).
% I.e. we get G with N humps. Here for convenience we set uoi = 2. This is
% unmollified. Mollified version of this case is below.

if (ca==2)

    if Y < 1
   
        z = (Y - 1) + 1/2;

    end
    
    if (Y >= 1 )
    
        z = (Y-1)/2 + 1/2 + sin((Y-1)*2*pi*N)/((4.1)*pi*N);

    end

end

% Case 3 is a mollified version of case 1. Here the mollification is set
% using delta specified above.

if (ca==3)

dom = linspace(Y-delta,Y+delta,101);
zm  = zeros(101,1);

for f=1:101

    if dom(f) < 1
   
        zm(f) = 1 + (dom(f) - 1) + ((1-X)/4);
    
    else
    
        zm(f) = 1 + ((dom(f)-X)/4);
  
    end

end

z = mean(zm,'all');

clear dom f zm

end

% Case 4
% This is mollified version of case 2. Here the mollification is set
% using delta specified above.

if (ca==4)

    dom = linspace(Y-delta,Y+delta,101);
    zm  = zeros(101,1);

    for f=1:101

        if dom(f) < 1
   
            zm(f) = (dom(f) - 1) + 1/2;

        end
    
        if (dom(f) >= 1 )
    
            zm(f) = (dom(f)-1)/2 + 1/2 + sin((dom(f)-1)*2*pi*N)/((4.1)*pi*N);

        end

    end

    z = mean(zm,'all');

    clear dom f zm

end

end
