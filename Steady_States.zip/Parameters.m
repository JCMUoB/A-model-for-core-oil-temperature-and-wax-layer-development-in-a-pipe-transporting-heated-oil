% Parameters (Steady State)

mu      = 0.5;  
ka      = 10;  % ka > k
k       = 2;   % k < ka
uoi     = 2;   % uoi > 1

% The functions D and u_h are defined elsewhere. 

dz      = 0.004;
Nz      = 1000;
