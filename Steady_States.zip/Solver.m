% New Solver based on that used in March 2024
% This is used to approximate the steady states given in Figures 8, 10 and
% 12 in the related article.

% First load parameters

Parameters

% Initialise uob, zd and hs

uob     = zeros(1,Nz);
h       = zeros(1,Nz);
z       = linspace(0,Nz*dz,Nz);

% Set initial conditions

uob(1)  = uoi;
h(1)    = max(G(uob(1),uoi) - 1/k,0);

%Solve for the rest of uob and h

Gtemp = 0;

for i = 1:Nz-1

    Gtemp = G(uob(i),uoi);

    if (Gtemp <= 1/k)

        uob(i+1) = uob(i) - (dz*mu*ka*uob(i)/(1+ka));
        h(i+1) = 0;

    else

        uob(i+1) = uob(i) - (dz*mu*(uob(i)-uh(uoi,uob(i))));
        h(i+1) = G(uob(i+1),uoi) - 1/k;

    end

end
