function [outputArg] = G(X,Y)
%Computes G for X being ... just X and Y being uoi.

outputArg = (Y-1)*uh(Y,X)/(X-uh(Y,X));

end 

%Note that when the D(u)=1 everywhere (as in the article), there is
%an expicit solution respresentation for the problem in the x variable,
%which is readily adapted from that given in Section 3.1 of Needham et al. 
%(JEM 131:7, 2021).